import React from 'react'
import './App.css';

export default function Home() {
  return (
    <div className='App'>
        <h1 style={{backgroundColor:'white'}}>Ahmed To Do App</h1>
    </div>
  )
}
